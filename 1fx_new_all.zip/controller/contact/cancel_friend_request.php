<?php

require_once($_SERVER['DOCUMENT_ROOT'].'/controller/shared/config.php');

extract($_POST);

// email to be added

//current email logged in
$queryCurrentEmail = "SELECT * FROM users WHERE email = '$current_email'";
$CurrentEmailQuery = mysql_query($queryCurrentEmail) or die (mysql_error()); 
	$CurrentEmailRow = mysql_fetch_array($CurrentEmailQuery);
$currentEmail = $CurrentEmailRow['id'];

// var_dump($add_email . " - " . $currentEmail);

//checking if its available
$check_query = "DELETE FROM contacts WHERE user_id = '$add_email' AND contact_id = '$currentEmail'";

mysql_query($check_query);

	
$ret = array(
	'status' => 'success',
	'message' => 'Successfully Deleted!'
);

echo json_encode($ret);

exit();
