<?php


	require_once($_SERVER['DOCUMENT_ROOT'].'/controller/shared/config.php');	

	$eMail = "";
	$credit_card_id = "";

	if (isset($_REQUEST['action']) ) {

		$eMail = isset($_REQUEST['email']) ? $_REQUEST['email'] : null;
		$credit_card_id = isset($_REQUEST['payment_result']) ? $_REQUEST['payment_result'] : null;
		
	}

	$query = "UPDATE users SET credit_card_token = '$credit_card_id' WHERE  email = '$eMail'"; // workable

	mysql_query($query);
		
	$ret = array(
		'status' => "success",
		'credit_card_token'=> $credit_card_id,
		'email'=> $eMail,
		'redirect' => 'credits.html',
		'message' => "Credit Card was successfully saved."
	);

	echo json_encode($ret);

	exit();
	
?>
