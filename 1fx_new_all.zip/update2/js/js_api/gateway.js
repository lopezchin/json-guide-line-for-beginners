$.ajax({
  	type: "GET",
	dataType: "xml",
	url: "http://192.168.1.70/TCC/gateway.php",
	contentType: "application/json; charset=utf-8",
	success: function(gatewayToken) {

		$(gatewayToken).find('gateway').each(function () {
            var gateway_token = $(this).find('token').text();

            console.log(gateway_token);

            $('#gatewayToken').val(gateway_token);
        });
	}
	
});