$.ajax({
  type: "POST",
  url: "http://192.168.1.70/TCC/auth.php",
  dataType: "json",
  success: function(result) {
    console.log(result);
    console.log('status = '+result.status);
    

    if (result.status == "success") {
        var tokenKey = result.token_id,
            email = result.email;

        $('#token').val(tokenKey);
        $('#email').val(email);

        contact_friend_requesting(email);

        contact_friend_pending(email);

        contact_friend_active(email);

    } else {
        var redirect = result.redirect;

        $('#update_prof').html(result.message);
        $(".bs-example-modal-sm").modal('show');
        
        window.location = redirect;
    }
  }
});

function contact_friend_active(email){
    $.ajax({ //working
      type: 'POST',
      dataType: 'json',
      url: 'http://192.168.1.70/controller/contact/fetch_all_contact.php?status=friend', //perfectly working
      data:{
        'email': email,
        '_token' : '',
        'action' : 'request_active'
      },
      success: function(contact_fetch_data) {

        console.log(contact_fetch_data);

        $.each( contact_fetch_data, function( key, value ) {

          var contact_result = '<tr><td><img src="http://192.168.1.70/controller/uploads/'+value.avatar+'" alt="image" class="img-circle avatar hidden-phone" width="120" height="45"/><a href="user-profile.html" class="name" >'+value.fullname+'</a><span class="subtext">'+value.company+'</span></td><td>'+value.address+'</td><td>$ 549.99</td><td class="align-right"><a href="#" >'+value.email+'</a></td><td>'+value.request_status+'</td></tr>';

          $("#contact_friend").append(contact_result); //use append when you are using the each loop for ajax
        });   
      }
    }); 
}

function contact_friend_requesting(email){

    $.ajax({ //working
      type: 'POST',
      dataType: 'json',
      url: 'http://192.168.1.70/controller/contact/fetch_all_contact.php?status=requesting', //perfectly working
      data:{
        'email': email,
        '_token' : '',
        'action' : 'requesting'
      },
      success: function(contact_fetch_data) {

        console.log(contact_fetch_data);

        $.each( contact_fetch_data, function( key, value ) {

          var contact_result = '<tr><td><img src="http://192.168.1.70/controller/uploads/'+value.avatar+'" alt="image" class="img-circle avatar hidden-phone" width="120" height="45"/><a href="user-profile.html" class="name">'+value.fullname+'</a><span class="subtext">'+value.company+'</span></td><td>'+value.address+'</td><td>$ 549.99</td><td class="align-right"><a href="#">'+value.email+'</a></td><td>'+value.request_status+'</td></tr>';

          $("#contact_friend").append(contact_result); //use append when you are using the each loop for ajax
        });   
      }
    }); 
}

function contact_friend_pending(email){

     $.ajax({ //working
      type: 'POST',
      dataType: 'json',
      url: 'http://192.168.1.70/controller/contact/fetch_all_contact.php?status=pending', //perfectly working
      data:{
        'email': email,
        '_token' : '',
        'action' : 'request_pending'
      },
      success: function(contact_fetch_data) {

        console.log(contact_fetch_data);

        $.each( contact_fetch_data, function( key, value ) {

          var contact_result = '<tr><td><img src="http://192.168.1.70/controller/uploads/'+value.avatar+'" alt="image" class="img-circle avatar hidden-phone" width="120" height="45"/><a href="user-profile.html" class="name">'+value.fullname+'</a><span class="subtext">'+value.company+'</span></td><td>'+value.address+'</td><td>$ 549.99</td><td class="align-right"><a href="#">'+value.email+'</a></td><td>'+value.request_status+'</td><td><a href="#" class="btn btn-primary btn-xs actionBtn" data-action="accept" data-emailrequesting="'+value.id+'"><i class="fa fa-check"></i><a/></td><td><a href="#" class="btn btn-default btn-xs actionBtn" data-action="cancel" data-emailrequesting="'+value.id+'" ><i class="fa fa-times"></i><a/></td></tr>';

          $("#contact_friend").append(contact_result); //use append when you are using the each loop for ajax
        });   
      }
    }); 
}


$(document).on("click", ".actionBtn", function(){

    var action = $(this).data("action"),
        add_email = $(this).data("emailrequesting"),
        current_email = $("#email").val();

    if(action == "accept"){
        // alert(action+"\n\n"+current_email+"\n\n"+add_email);
        $.ajax({
          type: "POST",
          url: "http://192.168.1.70/controller/contact/accept_friend_request.php",
          dataType: "json",
          data:{
            'current_email': current_email,
            'add_email': add_email,
            '_token': "",
            'action': action
          },
          success: function(result) {

            if(result.status === 'success'){
                location.reload();
                // window.redirect = result.redirect;
            }
            else{
                // window.redirect = result.redirect;
            }
          }
        });

    }else{
        // alert(action+"\n\n"+current_email+"\n\n"+add_email);

         $.ajax({
          type: "POST",
          url: "http://192.168.1.70/controller/contact/cancel_friend_request.php",
          dataType: "json",
          data:{
            'current_email': current_email,
            'add_email': add_email,
            '_token': "",
            'action': action
          },
          success: function(result) {

            if(result.status === 'success'){
                location.reload();
                // window.redirect = result.redirect;
            }
            else{
                // window.redirect = result.redirect;
            }
          }
        });
    }
});