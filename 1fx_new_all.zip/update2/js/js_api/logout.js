$("#logout").click(function (e) {
    e.preventDefault();
    $.ajax({
      type: "POST",
      url: "http://192.168.1.70/controller/logout.php",
      dataType: "json",
      data:{
        'logging_out': 'logout',
        '_token': "",
        'action': 'logout_app'
      },
      success: function(result) {

        if(result.status === 'logout'){
            alert("Thanks for using 1FX Mobile Wallet.");
            window.location = result.redirect;
        } else {
            // window.redirect = result.redirect;
        }
      }
    });
});// logout ajax