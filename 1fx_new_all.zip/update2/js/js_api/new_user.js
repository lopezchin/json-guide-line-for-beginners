$.ajax({
  type: "POST",
  url: "http://192.168.1.70/TCC/auth.php",
  dataType: "json",
  success: function(result) {
    console.log(result);
    console.log('status = '+result.status);
    

    if (result.status == "success") {
        var tokenKey = result.token_id;
        var email = result.email;
        
        document.getElementById('token').value = tokenKey;
        document.getElementById('email').value = email;
        document.getElementById('current_email').value = email;
      
    } else {
        var red = result.redirect;
        
        window.location = red;
    }
  }
});

$(document).on('click','#add_friend',function(e){
  e.preventDefault();

  var $form = $('form[name="addEmail"]'),
      data;
  if($form.valid()){
    data = $form.serialize();

    // alert(data); //
    ajax_addEmail(data);
  }
});

$('form[name="addEmail"]').validate({
  debug: true,
  rules : {
    add_email : {
      required: true,
      email :true,
      remote : {
        url: "http://192.168.1.70/controller/validate_notexist.php",
          type: "post",
          data: {
            email: function() {
            return $( "#add_email" ).val();
          }
        }
      }
    }
  },
  messages : {
    add_email : {
      required : "Dont Leave blank",
      email : "Please check inputted email!",
      remote : "Cannot add if email is not exist!."
    }
  }
});

var ajax_addEmail = function(data){
  $.ajax({
    url : "http://192.168.1.70/controller/contact/add_friend_contact.php",
    type: "post",
    dataType : "json",
    data : data,
    success: function(result){
      if(result.status == 'success'){
        // console.log(result);
        window.location = result.redirect;
      }
      else{
        // alert(result.message);
        $('.bs-example-modal-sm').modal('show');
        document.getElementById('already_friend').innerHTML = "<div style='text-align:center;'>"+result.message+"</div>";
      }
    },
    error: function(xhr,status){
      alert(xhr.responseText);
    }
  });
} 