//beneficiary API

$(document).on('click','#beneficiary_btn',function(e){
  e.preventDefault();
  var token_key = $("#token").val();
  var $form = $('form[name="beneficiary"]'),
      benef;
  if($form.valid()){
    benef = 'token_key='+token_key+'&'+$form.serialize();

    // alert(benef);
    ajax_benef(benef);
  }
});

//event handler for submit button
$('form[name="beneficiary"]').validate({
  debug: true,
  rules : {
    nickname : "required",
    account_ccy : "required",
    beneficiary_name : "required",
    bank_name : "required",
    bank_address : "required",
    account_number : "required",
    sort_code : "required",
    destination_code : "required"
  },
  messages : {
    nickname : "",
    account_ccy : "",
    beneficiary_name : "",
    bank_name : "",
    bank_address : "",
    account_number : "",
    sort_code : "",
    destination_code : ""
  }
});

var ajax_benef = function(benef){
  $.ajax({
    url : "http://192.168.1.70/TCC/beneficiary.php",
    type: "post",
    dataType : "json",
    data : benef,
    success: function(result){
      if(result.status == 'success'){
        console.log(result);
        // window.location = result.redirect;
        var email = $("#email").val(); 
        var benID = result.data.beneficiary_id
        // alert(result.status);
        beneficiary_id(benID, email);
      }
      else{
        alert(result.status);
      }
    },
    error: function(xhr,status){
      alert(xhr.responseText);
    }
  });
}

function beneficiary_id(benID, email){

    alert(benID+"\n\n"+email);
    
    var msg="";

    $.ajax({
      type: 'POST',
      dataType: 'json',
      url: 'http://192.168.1.70/controller/ben_id.php',
      data: {
        'email': email,
        'beneficiary_id': benID,
        _token: "",
        action: 'beneficiary_id_act'
      },

      success: function(objbenefId) {

        console.log(objbenefId);

        window.location = objbenefId.redirect;

      }
    });
}


// trade API

$(document).on('click','#trade_ben',function(e){
  e.preventDefault();
  var token_key = $("#token").val();
  var $form = $('form[name="tradeForm"]'),
      tradeBen;
  if($form.valid()){
    tradeBen = 'token_key='+token_key+'&'+$form.serialize();

    // alert(tradeBen);
    ajax_trade(tradeBen);
  }
});

//event handler for submit button
$('form[name="tradeForm"]').validate({
  debug: true,
  rules : {
    buy_currency : "required",
    amount_ben : "required",
    sell_currency : "required",
    side : "required",
    term_agreement_ben : "required",
    reason_ben : "required",
    beneficiary_id : "required",
    payment_ben_type : "required",
    payment_ref : "required"
  },
  messages : {
    buy_currency : "",
    amount_ben : "",
    sell_currency : "",
    side : "",
    term_agreement_ben : "Need to accept the Terms and Agreement",
    reason_ben : "",
    beneficiary_id : "",
    payment_ben_type : "",
    payment_ref : ""
  }
});

var ajax_trade = function(tradeBen){
  $.ajax({
    url : "http://192.168.1.70/TCC/trade_ben.php",
    type: "POST",
    dataType : "json",
    data : tradeBen,
    success: function(result){
      if(result.status == 'success'){

        console.log(result);
        // window.location = result.redirect;
        var tradeID = result.data.trade_id
        // alert(result.status);
        alert(tradeID);

      }else{

        alert(result.status);

      }
    },
    error: function(xhr,status){
      alert(xhr.responseText);
    }
  });
}  


// credit card ------------------------------------------------------- //

$(document).on('click','#credit_card',function(e){
  e.preventDefault();
  var $form = $('form[name="creditCard"]'),
      cCard;
  if($form.valid()){
    // cCard = 'token_key='+token_key+'&'+$form.serialize();

    // alert(cCard);
    // ajax_credit(cCard);
    var firstName = $("#firstname").val();
    var lastName = $("#lastname").val();
    var cardNumber = $("#card_number").val();
    var month = $("#month").val();
    var year = $("#year").val();
    var cvv = $("#cvv").val();
    var payment_method_identifier = $("#method_id").val();
    var some_other_things = $("#msg").val();
    var email = $("#pm_email").val();

    // alert(firstName+'\n\n'+lastName+'\n\n'+cardNumber+'\n\n'+month+'\n\n'+year+'\n\n'+cvv+'\n\n'+email+'\n\n'+payment_method_identifier+'\n\n'+some_other_things);
    payment_method(firstName, lastName, cardNumber, month, year, cvv, payment_method_identifier, some_other_things, email);

  }
});

//event handler for submit button
$('form[name="creditCard"]').validate({
  debug: true,
  rules : {
    firstname : "required",
    lastname : "required",
    card_number : "required",
    month : "required",
    year : "required",
    cvv : "required",
    method_id : "required",
    msg : "required",
    email:{
      required: true,
      email: true
    }
  },
  messages : {
    firstname : "",
    lastname : "",
    card_number : "",
    month : "",
    year : "",
    cvv : "",
    method_id : "",
    msg : "",
    email:{
      required: true,
      email: true
    }
  }
});

function payment_method(firstName, lastName, cardNumber, month, year, cvv, payment_method_identifier, some_other_things, email){
   
  var card = {
    "payment_method":{
      "credit_card":{
        "first_name": firstName,
        "last_name": lastName,
        "number":cardNumber,
        "verification_value":cvv,
        "month":month,
        "year":year,
        "email": email
      },
      "data": {
        "my_payment_method_identifier": payment_method_identifier,
        "extra_stuff": {
          "some_other_things": some_other_things
        }
      }
    }
  } 
    var url = "https://core.spreedly.com/v1/payment_methods.json?environment_key=8swOjWN7iUOAozk0w0tj9gvMBY8";

    $.ajax({
      type: "POST",
      url: url,
      dataType: "json",
      data: card
    }).success(function(data) {
      console.log(data);
      var email = $("#email").val(); 
      var token_result = data.transaction.payment_method.token;

      paymentMethod_insert(email, token_result);

    }).error(function(request, status, error) {
      console.log(error);
      // alert('error');
      alert('Unexpected error');
    });
}

function paymentMethod_insert(email, token_result){
    
    $.ajax({
      type: 'POST',
      dataType: 'json',
      url: 'http://192.168.1.70/controller/credit_card.php',
      data: {
        'email': email,
        'payment_result': token_result,
        _token: "",
        action: 'payment_method_action'
      },

      success: function(objcredit) {

        console.log(objcredit);

        window.location = objcredit.redirect;

      }
    });
}


// make purchase ------------------------------------------------------- //

$(document).on('click','#proceed_purchase',function(e){
  e.preventDefault();
  var $form = $('form[name="purchaseCurrency"]'),
      data;
  if($form.valid()){

    // data = $form.serialize();
    // make_purchase(data);

    var process_token_request = $("#process_token_request").val();
    var process_amount = $("#process_amount").val();
    var currency_code = $("#currency_code").val();
    var gateway_token = $("#gatewayToken").val();

    make_purchase(process_token_request, process_amount, currency_code, gateway_token);

  }
});

//event handler for submit button
$('form[name="purchaseCurrency"]').validate({
  debug: true,
  rules : {
    process_token_request : "required",
    process_amount : "required",
    currency_code : "required"
  },
  messages : {
    process_token_request : "",
    process_amount : "",
    currency_code : ""
  }
});

function make_purchase(process_token_request, process_amount, currency_code, gateway_token){
  alert(process_token_request+'\n\n'+process_amount+'\n\n'+currency_code+'\n\n'+gateway_token);
   $.ajax({
        type: 'POST',
        url: 'http://192.168.1.70/controller/make_purchase.php',
        dataType: 'xml',
        data: {
          'gatewayToken': gateway_token,
          'processToken': process_token_request,
          'processAmount': process_amount,
          'currencyCode': currency_code,
          _token: '',
          action: 'makePurchase'
        }
    }).success(function(dataPP) {
      console.log(dataPP);
      
    }).error(function(request, status, errorPP) {
      console.log(errorPP);
    });
}