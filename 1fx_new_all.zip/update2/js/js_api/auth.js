$.ajax({
  type: "POST",
  // url: "http://1fx.philwebservicesdev.com/TCC/auth.php",
  url: "http://192.168.1.70/TCC/auth.php",
  dataType: "json",
  success: function(result) {
    console.log(result);
    console.log('status = '+result.status);
    

    if (result.status == "success") {
        var tokenKey = result.token_id;
        var email = result.email;

        $("#token").val(tokenKey);
        $("#email").val(email);

    } else {
        var red = result.redirect;
        
        window.location = red;
    }
  }
});
  